/* tricky.c */

/***
 *** a tricky comment ******/

int main(void)
{
    char c, *s;

    s = "I said \"hello there\"";
    c ++;
    --s;
}
